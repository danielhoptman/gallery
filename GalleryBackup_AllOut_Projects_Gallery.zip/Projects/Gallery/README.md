# GalleryBackup (All‑Out Build)

Drop this folder to:

`C:\Users\Owner\Projects\Gallery\`

## Run

```powershell
cd C:\Users\Owner\Projects\Gallery
dotnet restore
dotnet run --project .\GalleryBackup.App\GalleryBackup.App.csproj
```

## Features (now)
- Premium minimalist WPF UI (Dashboard / Devices / Backups / Settings)
- Postgres baked in (test) + SQLite fallback
- Scan rules: extensions + minimum size
- SHA‑256 dedupe
- Upload job queue + background worker (S3 compatible)
- Device detection: **Android ADB** (if adb installed) + stubs for MTP/iPhone

## Next
- MTP browsing + import (Windows Portable Devices API)
- iPhone import via Apple drivers or iTunes APIs (requires extra setup)
- Full settings page (live reload without restart)
