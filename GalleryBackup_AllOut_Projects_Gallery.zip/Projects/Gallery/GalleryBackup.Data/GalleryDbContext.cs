using Microsoft.EntityFrameworkCore;

namespace GalleryBackup.Data;

public sealed class GalleryDbContext : DbContext
{
    public GalleryDbContext(DbContextOptions<GalleryDbContext> options) : base(options) { }

    public DbSet<MediaItem> MediaItems => Set<MediaItem>();
    public DbSet<UploadJob> UploadJobs => Set<UploadJob>();
    public DbSet<Device> Devices => Set<Device>();
    public DbSet<BackupSession> BackupSessions => Set<BackupSession>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MediaItem>().HasIndex(x => x.Sha256).IsUnique();
        modelBuilder.Entity<Device>().HasIndex(x => x.DeviceId).IsUnique();
        modelBuilder.Entity<UploadJob>().HasIndex(x => new { x.Status, x.CreatedAt });
    }
}
