using System.ComponentModel.DataAnnotations;

namespace GalleryBackup.Data;

public sealed class MediaItem
{
    [Key] public long Id { get; set; }
    [MaxLength(128)] public string Sha256 { get; set; } = "";
    [MaxLength(512)] public string FileName { get; set; } = "";
    [MaxLength(64)] public string Extension { get; set; } = "";
    public long Bytes { get; set; }
    public DateTimeOffset DiscoveredAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? UploadedAt { get; set; }
    [MaxLength(1024)] public string? CloudKey { get; set; }
}

public sealed class UploadJob
{
    [Key] public long Id { get; set; }
    [MaxLength(128)] public string Sha256 { get; set; } = "";
    [MaxLength(2048)] public string LocalPath { get; set; } = "";
    [MaxLength(1024)] public string RelativeKey { get; set; } = "";
    public int Attempts { get; set; } = 0;
    public string Status { get; set; } = "Queued";
    public string? LastError { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? CompletedAt { get; set; }
}

public sealed class Device
{
    [Key] public long Id { get; set; }
    [MaxLength(256)] public string DeviceId { get; set; } = "";
    [MaxLength(256)] public string DisplayName { get; set; } = "";
    [MaxLength(64)] public string Kind { get; set; } = "";
    public DateTimeOffset FirstSeenAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset LastSeenAt { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class BackupSession
{
    [Key] public long Id { get; set; }
    public long? DeviceId { get; set; }
    public DateTimeOffset StartedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? FinishedAt { get; set; }
    public int Scanned { get; set; }
    public int Enqueued { get; set; }
    public int Uploaded { get; set; }
    public string Status { get; set; } = "Running";
}
