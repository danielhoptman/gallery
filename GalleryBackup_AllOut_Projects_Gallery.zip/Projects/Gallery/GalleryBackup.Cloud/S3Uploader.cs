using Amazon.S3;
using Amazon.S3.Model;
using GalleryBackup.Core.Config;

namespace GalleryBackup.Cloud;

public sealed class S3Uploader
{
    private readonly CloudOptions _cloud;
    public S3Uploader(CloudOptions cloud) => _cloud = cloud;

    public async Task<string> UploadAsync(string localPath, string relativeKey, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(_cloud.Bucket))
            throw new InvalidOperationException("Cloud bucket is not configured (App.Cloud.Bucket).");

        var key = $"{_cloud.Prefix.TrimEnd('/')}/{relativeKey.TrimStart('/')}".Replace("\", "/");
        using IAmazonS3 s3 = S3ClientFactory.Create(_cloud);
        await using var fs = File.OpenRead(localPath);

        var put = new PutObjectRequest
        {
            BucketName = _cloud.Bucket,
            Key = key,
            InputStream = fs,
            AutoCloseStream = false,
            ContentType = Guess(localPath)
        };
        await s3.PutObjectAsync(put, ct);
        return key;
    }

    private static string? Guess(string path) => Path.GetExtension(path).ToLowerInvariant() switch
    {
        ".jpg" or ".jpeg" => "image/jpeg",
        ".png" => "image/png",
        ".heic" => "image/heic",
        ".webp" => "image/webp",
        ".gif" => "image/gif",
        ".mp4" => "video/mp4",
        ".mov" => "video/quicktime",
        ".mkv" => "video/x-matroska",
        _ => null
    };
}
