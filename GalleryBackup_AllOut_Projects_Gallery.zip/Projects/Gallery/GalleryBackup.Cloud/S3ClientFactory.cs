using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using GalleryBackup.Core.Config;

namespace GalleryBackup.Cloud;

public static class S3ClientFactory
{
    public static IAmazonS3 Create(CloudOptions cloud)
    {
        var creds = new BasicAWSCredentials(cloud.AccessKeyId, cloud.SecretAccessKey);
        var cfg = new AmazonS3Config
        {
            RegionEndpoint = RegionEndpoint.GetBySystemName(cloud.Region),
            ForcePathStyle = cloud.UsePathStyle
        };
        if (!string.IsNullOrWhiteSpace(cloud.EndpointUrl))
            cfg.ServiceURL = cloud.EndpointUrl;
        return new AmazonS3Client(creds, cfg);
    }
}
