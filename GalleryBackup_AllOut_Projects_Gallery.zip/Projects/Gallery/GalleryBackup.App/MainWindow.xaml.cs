using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Forms;
using GalleryBackup.App.Views;
using GalleryBackup.Core.Config;
using GalleryBackup.Core.Services;
using GalleryBackup.Data;

namespace GalleryBackup.App;

public partial class MainWindow : Window
{
    private readonly BackupOrchestrator _backup;
    private readonly GalleryDbContext _db;
    private readonly DeviceDetector _devices;
    private readonly AppOptions _opt;

    public string Subtitle { get; set; } = "Premium minimalist • Local-first • Cloud-backed";
    public string StatusLine { get; set; } = "Go to Backups → choose a folder → then click Backup Now.";
    public string SelectedFolder { get; set; } = "No folder selected.";
    public string QueueLine { get; set; } = "Queued: 0 • Uploading: 0 • Done: 0 • Failed: 0";
    public string DeviceLine { get; set; } = "Devices: (not checked yet)";
    public string FooterHint { get; set; } = "Tip: configure Cloud bucket/keys in Settings to enable uploads.";

    public string CloudBucket { get; set; } = "";
    public string CloudAccessKey { get; set; } = "";

    private string? _folder;

    public MainWindow(BackupOrchestrator backup, GalleryDbContext db, DeviceDetector devices, AppOptions opt)
    {
        _backup = backup;
        _db = db;
        _devices = devices;
        _opt = opt;

        InitializeComponent();
        DataContext = this;

        // seed UI fields
        CloudBucket = _opt.Cloud.Bucket ?? "";
        CloudAccessKey = _opt.Cloud.AccessKeyId ?? "";

        ShowDashboard();
        RefreshStats();
    }

    private void SetContent(object view)
    {
        ContentHost.Content = view;
        DataContext = null;
        DataContext = this;
    }

    private void ShowDashboard() => SetContent(new DashboardView());
    private void ShowDevices() => SetContent(new DevicesView());
    private void ShowBackups() => SetContent(new BackupsView());
    private void ShowSettings() => SetContent(new SettingsView());

    private void GoDashboard(object sender, RoutedEventArgs e) { ShowDashboard(); RefreshStats(); }
    private void GoDevices(object sender, RoutedEventArgs e) { ShowDevices(); RefreshStats(); }
    private void GoBackups(object sender, RoutedEventArgs e)
    {
        // Use folder chooser right away for a premium feel
        ChooseFolder();
        ShowBackups();
        RefreshStats();
    }
    private void GoSettings(object sender, RoutedEventArgs e) { ShowSettings(); RefreshStats(); PromptSaveSettings(); }

    private void ChooseFolder()
    {
        using var dlg = new FolderBrowserDialog
        {
            Description = "Choose a folder containing photos/videos (e.g., DCIM).",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = false
        };

        if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            _folder = dlg.SelectedPath;
            SelectedFolder = _folder;
            StatusLine = "Ready. Click Backup Now to scan + enqueue uploads.";
        }
    }

    private void PromptSaveSettings()
    {
        // lightweight: show a message with where it saves
        FooterHint = "Settings save to %AppData%\\GalleryBackup\\appsettings.user.json";
    }

    private void SaveUserSettings(string? secretKey)
    {
        var appData = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GalleryBackup");
        System.IO.Directory.CreateDirectory(appData);
        var path = System.IO.Path.Combine(appData, "appsettings.user.json");

        var user = new
        {
            App = new
            {
                Cloud = new
                {
                    Bucket = CloudBucket ?? "",
                    AccessKeyId = CloudAccessKey ?? "",
                    SecretAccessKey = secretKey ?? "",
                }
            }
        };

        var json = JsonSerializer.Serialize(user, new JsonSerializerOptions { WriteIndented = true });
        System.IO.File.WriteAllText(path, json, Encoding.UTF8);

        StatusLine = "Saved. Restart the app to reload credentials (auto-reload UI coming next).";
    }

    private async void OnBackupClick(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_folder))
        {
            ChooseFolder();
            if (string.IsNullOrWhiteSpace(_folder)) return;
        }

        try
        {
            StatusLine = "Scanning…";
            RefreshStats();

            var (scanned, enqueued) = await _backup.ImportFolderAsync(_folder!, CancellationToken.None);
            StatusLine = $"Scan complete. Scanned {scanned} file(s), enqueued {enqueued} upload job(s). Uploads run in the background.";
            RefreshStats();
        }
        catch (Exception ex)
        {
            StatusLine = "Failed: " + ex.Message;
            RefreshStats();
        }
    }

    private void RefreshStats()
    {
        var queued = _db.UploadJobs.Count(x => x.Status == "Queued");
        var uploading = _db.UploadJobs.Count(x => x.Status == "Uploading");
        var done = _db.UploadJobs.Count(x => x.Status == "Done");
        var failed = _db.UploadJobs.Count(x => x.Status == "Failed");
        QueueLine = $"Queued: {queued} • Uploading: {uploading} • Done: {done} • Failed: {failed}";

        var devs = _devices.GetConnectedDevices();
        DeviceLine = devs.Count == 0 ? "Devices: none detected." : "Devices:\n" + string.Join("\n", devs.Select(d => $"{d.name} ({d.kind})"));

        DataContext = null;
        DataContext = this;
    }
}
