using System.Windows;
using System.Windows.Controls;

namespace GalleryBackup.App.Views;

public partial class SettingsView : UserControl
{
    public SettingsView() { InitializeComponent(); }

    private void OnSave(object sender, RoutedEventArgs e)
    {
        // MainWindow saves; this keeps the view simple.
        MessageBox.Show("Use the Save button in Settings on the main window (coming next).", "Settings");
    }
}
