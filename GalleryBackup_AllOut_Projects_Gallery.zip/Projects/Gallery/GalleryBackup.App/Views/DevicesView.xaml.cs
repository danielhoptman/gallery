using System.Windows;
using System.Windows.Controls;

namespace GalleryBackup.App.Views;

public partial class DevicesView : UserControl
{
    public DevicesView() { InitializeComponent(); }

    private void OnRefresh(object sender, RoutedEventArgs e)
    {
        // MainWindow owns refresh; this is a UI placeholder.
        MessageBox.Show("Use the left panel quick status (auto-refresh on navigation).", "Devices");
    }
}
