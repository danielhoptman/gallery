namespace GalleryBackup.App.Views; public partial class DashboardView { public DashboardView(){InitializeComponent();} }
