using System.Windows;
using System.Windows.Controls;

namespace GalleryBackup.App.Views;

public partial class BackupsView : UserControl
{
    public BackupsView() { InitializeComponent(); }

    private void OnChooseFolder(object sender, RoutedEventArgs e)
    {
        // MainWindow handles the dialog so bindings update consistently.
        MessageBox.Show("Click 'Backups' then use the left panel folder picker in the main window (coming next).", "Backups");
    }
}
