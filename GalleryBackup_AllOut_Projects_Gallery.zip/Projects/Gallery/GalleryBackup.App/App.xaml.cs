using System.Windows;

namespace GalleryBackup.App;

public partial class App : Application
{
}
