using System.IO;
using GalleryBackup.Core.Config;
using GalleryBackup.Core.Services;
using GalleryBackup.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Npgsql;

namespace GalleryBackup.App;

public static class Program
{
    [STAThread]
    public static void Main()
    {
        var host = CreateHost();
        var app = new App();
        var main = host.Services.GetRequiredService<MainWindow>();
        app.Run(main);
    }

    private static IHost CreateHost()
    {
        var appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GalleryBackup");
        Directory.CreateDirectory(appData);

        var config = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile(Path.Combine(appData, "appsettings.user.json"), optional: true, reloadOnChange: true)
            .Build();

        var opt = config.GetSection("App").Get<AppOptions>() ?? new AppOptions();

        var host = Host.CreateDefaultBuilder()
            .ConfigureServices(services =>
            {
                services.AddSingleton(opt);

                services.AddDbContext<GalleryDbContext>(db =>
                {
                    if (string.Equals(opt.Database.Provider, "Postgres", StringComparison.OrdinalIgnoreCase))
                    {
                        var pg = opt.Database.Postgres;
                        var csb = new NpgsqlConnectionStringBuilder
                        {
                            Host = pg.Host,
                            Port = pg.Port,
                            Database = pg.Database,
                            Username = pg.Username,
                            Password = pg.Password,
                            SslMode = pg.SslRequired ? SslMode.Require : SslMode.Disable,
                            TrustServerCertificate = pg.TrustServerCertificate
                        };
                        db.UseNpgsql(csb.ConnectionString);
                    }
                    else
                    {
                        var sqlitePath = opt.Database.SqlitePath;
                        if (string.IsNullOrWhiteSpace(sqlitePath))
                            sqlitePath = Path.Combine(appData, "gallerybackup.db");
                        db.UseSqlite($"Data Source={sqlitePath}");
                    }
                });

                services.AddSingleton<BackupOrchestrator>();
                services.AddSingleton<DeviceDetector>();
                services.AddHostedService<UploadWorker>();

                services.AddSingleton<MainWindow>();
            })
            .Build();

        using (var scope = host.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<GalleryDbContext>();
            db.Database.EnsureCreated();
        }

        return host;
    }
}
