using System.Diagnostics;
using System.Text;

namespace GalleryBackup.Core.Services;

public sealed class DeviceDetector
{
    public IReadOnlyList<(string id, string name, string kind)> GetConnectedDevices()
    {
        var list = new List<(string, string, string)>();

        // Android via adb (if installed)
        try
        {
            var adb = new ProcessStartInfo
            {
                FileName = "adb",
                Arguments = "devices -l",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            using var p = Process.Start(adb);
            if (p != null)
            {
                var output = p.StandardOutput.ReadToEnd();
                p.WaitForExit(1500);
                foreach (var line in output.Split('\n'))
                {
                    var t = line.Trim();
                    if (string.IsNullOrWhiteSpace(t)) continue;
                    if (t.StartsWith("List of devices")) continue;
                    if (!t.Contains("\tdevice")) continue;

                    var id = t.Split('\t')[0].Trim();
                    list.Add((id, "Android device", "AndroidADB"));
                }
            }
        }
        catch
        {
            // adb not installed; ignore
        }

        return list;
    }
}
