using GalleryBackup.Cloud;
using GalleryBackup.Core.Config;
using GalleryBackup.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace GalleryBackup.Core.Services;

public sealed class UploadWorker : BackgroundService
{
    private readonly IServiceProvider _sp;
    private readonly ILogger<UploadWorker> _log;
    private readonly AppOptions _opt;

    public UploadWorker(IServiceProvider sp, ILogger<UploadWorker> log, AppOptions opt)
    {
        _sp = sp;
        _log = log;
        _opt = opt;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _log.LogInformation("UploadWorker started.");
        while (!stoppingToken.IsCancellationRequested)
        {
            try { await ProcessOnce(stoppingToken); }
            catch (Exception ex) { _log.LogError(ex, "UploadWorker error"); }

            await Task.Delay(1500, stoppingToken);
        }
    }

    private async Task ProcessOnce(CancellationToken ct)
    {
        using var scope = _sp.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<GalleryDbContext>();

        var job = await db.UploadJobs
            .Where(x => x.Status == "Queued" || (x.Status == "Failed" && x.Attempts < 3))
            .OrderBy(x => x.CreatedAt)
            .FirstOrDefaultAsync(ct);

        if (job is null) return;

        job.Status = "Uploading";
        job.Attempts += 1;
        await db.SaveChangesAsync(ct);

        try
        {
            var uploader = new S3Uploader(_opt.Cloud);
            var cloudKey = await uploader.UploadAsync(job.LocalPath, job.RelativeKey, ct);

            var item = await db.MediaItems.FirstOrDefaultAsync(x => x.Sha256 == job.Sha256, ct);
            if (item is not null)
            {
                item.CloudKey = cloudKey;
                item.UploadedAt = DateTimeOffset.UtcNow;
            }

            job.Status = "Done";
            job.CompletedAt = DateTimeOffset.UtcNow;
            job.LastError = null;
            await db.SaveChangesAsync(ct);
        }
        catch (Exception ex)
        {
            job.Status = "Failed";
            job.LastError = ex.Message;
            await db.SaveChangesAsync(ct);
        }
    }
}
