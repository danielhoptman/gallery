using GalleryBackup.Core.Config;

namespace GalleryBackup.Core.Services;

public sealed class GalleryScanner
{
    private readonly ScanRules _rules;
    public GalleryScanner(ScanRules rules) => _rules = rules;

    public IEnumerable<string> EnumerateMediaFiles(string folder)
    {
        if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder))
            yield break;

        var allowed = new HashSet<string>(_rules.AllowedExtensions.Select(x => x.ToLowerInvariant()));
        foreach (var file in Directory.EnumerateFiles(folder, "*.*", SearchOption.AllDirectories))
        {
            var ext = Path.GetExtension(file).ToLowerInvariant();
            if (!allowed.Contains(ext)) continue;

            var info = new FileInfo(file);
            if (info.Length < _rules.MinBytes) continue;

            yield return file;
        }
    }

    public static string BuildRelativeKey(string sha256, string originalFileName)
    {
        var date = DateTime.UtcNow;
        var aa = sha256[..2];
        var bb = sha256.Substring(2, 2);
        var safeName = string.Join("_", originalFileName.Split(Path.GetInvalidFileNameChars())).Trim();
        if (safeName.Length > 120) safeName = safeName[..120];
        return $"{date:yyyy/MM/dd}/{aa}/{bb}/{sha256}-{safeName}";
    }
}
