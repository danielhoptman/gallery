using System.Security.Cryptography;

namespace GalleryBackup.Core.Services;

public static class Hashing
{
    public static async Task<string> Sha256HexAsync(string filePath, CancellationToken ct)
    {
        await using var fs = File.OpenRead(filePath);
        using var sha = SHA256.Create();
        var hash = await sha.ComputeHashAsync(fs, ct);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }
}
