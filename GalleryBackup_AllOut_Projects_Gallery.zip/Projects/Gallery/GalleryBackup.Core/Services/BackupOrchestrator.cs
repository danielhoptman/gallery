using GalleryBackup.Core.Config;
using GalleryBackup.Data;
using Microsoft.EntityFrameworkCore;

namespace GalleryBackup.Core.Services;

public sealed class BackupOrchestrator
{
    private readonly GalleryDbContext _db;
    private readonly GalleryScanner _scanner;

    public BackupOrchestrator(GalleryDbContext db, AppOptions opt)
    {
        _db = db;
        _scanner = new GalleryScanner(opt.Rules);
    }

    public async Task<(int scanned, int enqueued)> ImportFolderAsync(string folder, CancellationToken ct)
    {
        var session = new BackupSession { StartedAt = DateTimeOffset.UtcNow, Status = "Running" };
        _db.BackupSessions.Add(session);
        await _db.SaveChangesAsync(ct);

        int scanned = 0, enqueued = 0;

        foreach (var file in _scanner.EnumerateMediaFiles(folder))
        {
            ct.ThrowIfCancellationRequested();
            scanned++;

            var sha = await Hashing.Sha256HexAsync(file, ct);
            if (await _db.MediaItems.AnyAsync(x => x.Sha256 == sha, ct))
                continue;

            var info = new FileInfo(file);
            _db.MediaItems.Add(new MediaItem
            {
                Sha256 = sha,
                FileName = info.Name,
                Extension = info.Extension.ToLowerInvariant(),
                Bytes = info.Length,
                DiscoveredAt = DateTimeOffset.UtcNow
            });

            _db.UploadJobs.Add(new UploadJob
            {
                Sha256 = sha,
                LocalPath = file,
                RelativeKey = GalleryScanner.BuildRelativeKey(sha, info.Name),
                Status = "Queued"
            });

            enqueued++;
        }

        session.Scanned = scanned;
        session.Enqueued = enqueued;
        session.FinishedAt = DateTimeOffset.UtcNow;
        session.Status = "Completed";
        await _db.SaveChangesAsync(ct);

        return (scanned, enqueued);
    }
}
