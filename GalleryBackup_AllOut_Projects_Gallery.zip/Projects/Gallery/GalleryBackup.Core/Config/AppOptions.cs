namespace GalleryBackup.Core.Config;

public sealed class AppOptions
{
    public DatabaseOptions Database { get; set; } = new();
    public CloudOptions Cloud { get; set; } = new();
    public ScanRules Rules { get; set; } = new();
}

public sealed class DatabaseOptions
{
    public string Provider { get; set; } = "Sqlite";
    public string? SqlitePath { get; set; } = null;
    public PostgresOptions Postgres { get; set; } = new();
}

public sealed class PostgresOptions
{
    public string Host { get; set; } = "";
    public int Port { get; set; } = 5432;
    public string Database { get; set; } = "";
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public bool SslRequired { get; set; } = true;
    public bool TrustServerCertificate { get; set; } = false;
}

public sealed class CloudOptions
{
    public string Provider { get; set; } = "S3";
    public string? EndpointUrl { get; set; } = null;
    public string Region { get; set; } = "ap-southeast-2";
    public string Bucket { get; set; } = "";
    public string Prefix { get; set; } = "gallery/";
    public string AccessKeyId { get; set; } = "";
    public string SecretAccessKey { get; set; } = "";
    public bool UsePathStyle { get; set; } = false;
}

public sealed class ScanRules
{
    public List<string> AllowedExtensions { get; set; } = new() { ".jpg", ".jpeg", ".png", ".mp4", ".mov" };
    public long MinBytes { get; set; } = 10_240;
}
